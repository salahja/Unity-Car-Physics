using UnityEngine;
using UnityEngine;

public class Coin : MonoBehaviour
{
    [Header("Rotation Settings")]
    [SerializeField] private float rotationSpeed = 70f;
    [SerializeField] private Vector3 rotationAxis = Vector3.right; // Rotates around X-axis by default

    [Header("Effects")]
    [SerializeField] private ParticleSystem collectEffect;
    [SerializeField] private string coinSoundName = "Coin";

    [Header("Collection")]
    [SerializeField] private float collectionDelay = 0.1f; // Delay before destruction to allow effects to play
    [SerializeField] private bool disableInsteadOfDestroy = false; // For object pooling

    private Collider coinCollider;
    private MeshRenderer coinRenderer;
    private AudioManager audioManager;

    private void Awake()
    {
        coinCollider = GetComponent<Collider>();
        coinRenderer = GetComponentInChildren<MeshRenderer>();
        audioManager = FindObjectOfType<AudioManager>();
    }

    private void Update()
    {
        // Smooth rotation
        transform.Rotate(rotationAxis * rotationSpeed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            CollectCoin();
        }
    }

    private void CollectCoin()
    {
        // Disable visual and collider immediately
        if (coinCollider != null) coinCollider.enabled = false;
        if (coinRenderer != null) coinRenderer.enabled = false;

        // Play sound if available
        if (audioManager != null && !string.IsNullOrEmpty(coinSoundName))
        {
            audioManager.PlaySound(coinSoundName);
        }

        // Play particle effect if available
        if (collectEffect != null)
        {
            collectEffect.Play();
        }

        // Increment coin count
        PlayerManager.numberOfCoins += 1;

        // Handle destruction/disable
        if (disableInsteadOfDestroy)
        {
            StartCoroutine(DisableAfterDelay());
        }
        else
        {
            Destroy(gameObject, collectionDelay);
        }
    }

    private System.Collections.IEnumerator DisableAfterDelay()
    {
        yield return new WaitForSeconds(collectionDelay);
        gameObject.SetActive(false);
        
        // Reset for next use if object pooling
        if (coinCollider != null) coinCollider.enabled = true;
        if (coinRenderer != null) coinRenderer.enabled = true;
    }

    // For object pooling - reset the coin when re-activated
    private void OnEnable()
    {
        if (coinCollider != null) coinCollider.enabled = true;
        if (coinRenderer != null) coinRenderer.enabled = true;
    }
}